<div class="modal fade" id="report-livelink-modal" tabindex="-1" role="dialog" aria-labelledby="newArticleModalLabel"
	    aria-hidden="true" data-backdrop="static" data-keyboard="false">
	    <div class="modal-dialog modal-center-viewport modal-dialog-centered modal-lg" role="document">
	        <div class="modal-content">
			    <div class="modal-header">
				    <h5 class="modal-title">Live Links</h5>
			    </div>
	            <div class="modal-body">
                     				
	            </div>
			    <div class="modal-footer">
			        <button type="button" class="btn btn-link text-danger" data-dismiss="modal">Close</button>
			    </div>
	            
	        </div>
	    </div>
	</div>
</div>