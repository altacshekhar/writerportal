	<div class="modal fade" id="ctaPreviewModal" tabindex="-1" role="dialog" aria-labelledby="ctaPreviewModal"
	    aria-hidden="true" data-backdrop="static" data-keyboard="false">
	    <div class="modal-dialog modal-center-viewport modal-dialog-centered modal-lg" role="document">
	        <div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">CTA Preview</h5>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
	             <div class="modal-body">
	              <div class="preview">
				  </div>
	            </div>
			<div class="modal-footer">
			    <button type="button" class="btn btn-link text-danger" data-dismiss="modal">Close</button>
			</div>
	            <!-- End Signin -->
	            <?php echo form_close(); ?>
	        </div>
	    </div>
	</div>
	</div>