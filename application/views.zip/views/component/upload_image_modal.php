	<div id="uploadimageModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="uploadimageModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content p-1">
				<div class="modal-header">
					<h5 class="modal-title h3">Upload & Crop Image</h5>
				</div>
				<div class="modal-body">
					<div id="image_demo"></div>
				</div>
				<div class="modal-footer">
					<button class="btn btn-warning btn-sm crop_image">
						<i class="fas fa-upload"></i>
						Crop & Use Image
					</button>
					<button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">
						<i class="fas fa-times"></i>
						Close
					</button>
				</div>
			</div>
		</div>
	</div>