<div id="copyscape-result" class="modal fade" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content p-1">
			<div class="modal-header pt-0 pb-0">
				<h4 class="modal-title">Copyscape Result</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div id="copyscape-result-container" class="modal-body"></div>
		</div>
	</div>
</div>