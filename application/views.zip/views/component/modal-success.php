<div class="modal fade" id="modal-success" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog modal-confirm" role="document">
		<div class="modal-content">
			<div class="modal-body d-flex justify-content-center">
				<div class="mt-2 w-75">
					<div class="f-modal-alert">
						<div class="f-modal-icon f-modal-success animate">
							<span class="f-modal-line f-modal-tip animateSuccessTip"></span>
							<span class="f-modal-line f-modal-long animateSuccessLong"></span>
							<div class="f-modal-placeholder"></div>
							<div class="f-modal-fix"></div>
						</div>
					</div>
					<div class="clearfix text-center">
						<h3 class="h1 mt-1 mb-2">Success</h3>
						<p id="modal-success-msg" class="modal-success-msg text-muted">If published, the article will be removed from the website on the next update.</p>
					</div>
				</div>
			</div>
			<div class="modal-footer modal-footer-borderless justify-content-center">
				<button type="button" class="btn btn-success mt-1 mb-2" data-dismiss="modal">Ok</button>
			</div>
		</div>
	</div>
</div>