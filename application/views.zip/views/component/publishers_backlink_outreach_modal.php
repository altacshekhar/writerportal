	<div class="modal fade" id="publishersBacklinkOutreachModal" tabindex="-1" role="dialog" aria-labelledby="newArticleModalLabel"
	    aria-hidden="true" data-backdrop="static" data-keyboard="false">
	    <div class="modal-dialog modal-center-viewport modal-dialog-centered modal-lg" role="document">
	        <div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Publishers</h5>
			</div>
	             <div class="modal-body">
	                <?php
						//$attributes = array('class' => 'form-horizontal form-hub-secure', 'id' => 'articlebuildbacklinks-form');
						//echo form_open('', $attributes);
					?>
					<div class="row ml-1 mr-1 ">
						<div class="table-responsive" style="max-height:350px">
							<table class="table table-bordered">
								<thead>
									<tr>
									<th scope="col">Publisher</th>
									<th scope="col">Traffic</th>
									<th scope="col">DA</th>
									<th scope="col">Cost</th>
									<th scope="col">Campaigns</th>
									<th scope="col"></th>
									</tr>
								</thead>
								<tbody style="overflow-y: auto">
									
								</tbody>
							</table>
						</div>
					</div>
						
	            </div>
			<div class="modal-footer">
			    <button type="button" class="btn btn-link text-danger" data-dismiss="modal">Done</button>
			</div>
	            <!-- End Signin -->
	            <?php //echo form_close(); ?>
	        </div>
	    </div>
	</div>
	</div>