                <div class="container">
						<ul class="nav nav-tabs brief-nav-tabs" id="sideTab" role="tablist">
							<li class="nav-item">
								<a class="nav-link active" id="top-results-tab" data-toggle="tab" href="#topresults" role="tab" aria-controls="topresults" aria-selected="true">Top Results</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" id="topics-tab" data-toggle="tab" href="#topics" role="tab" aria-controls="topics" aria-selected="false">Topics</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" id="questions-tab" data-toggle="tab" href="#questions" role="tab" aria-controls="questions" aria-selected="false">Questions</a>
							</li>
						</ul>
					</div>
					<div class="tab-content" id="sideTabContent">
						<!-- Top Results Tab -->
						<div class="tab-pane fade show active" id="topresults" role="tabpanel" aria-labelledby="top-results-tab">
							<div class="container">
								<ul class="nav nav-tabs topresults-tab" id="subsideTab" role="tablist">
									<li class="nav-item">
										<a class="nav-link active" id="overview-tab" data-toggle="tab" href="#overview" role="tab" aria-controls="overview" aria-selected="true">Overview</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" id="links-tab" data-toggle="tab" href="#links" role="tab" aria-controls="links" aria-selected="false">Links</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" id="stats-tab" data-toggle="tab" href="#stats" role="tab" aria-controls="stats" aria-selected="false">Stats</a>
									</li>
								</ul>
							</div>
							<div class="tab-content" id="subsideTabContent">
								<!-- Start of Overview Tab -->
								<div class="tab-pane fade show active" id="overview" role="tabpanel" aria-labelledby="overview-tab">
									<div class="container document-search-results ">
										<div class="document-search-summary-meta pt-2">
											<img class="favicon" src="https://www.google.com/s2/favicons?domain_url=capterra.com">
											<span><a class="text-secondary" href="https://www.capterra.com/employee-scheduling-software/" target="_blank"><u>capterra.com</u></a></span>
											<span>Sept 17,2020</span>
											<span>727 Words</span>
										</div>
										<h2>Best Employee Scheduling Software 2020 | Reviews of the Most Popular Tools & Systems</h2>
										<p>Find and compare top Employee Scheduling software on Capterra, with our free ... app that's both powerful, affordable and easy to use, especially for the mobile ...</p>
										<div id="accordion-1" class="accordion">
											<div class="card border-default">
												
												<div class="alert alert-secondary alert-default d-flex mb-1 m-0 collapsed" id="heading-1-1" data-toggle="collapse" role="button" data-target="#collapse-1-1" aria-expanded="false" aria-controls="collapse-1-1" style="">
													<div>
													<h6 class="text-default mb-0"><i class="icon-action fa fa-chevron-down" style="font-size: 12px"></i> Outline 1</h6>
													<span>Content dfdsfsda fdfsafsdfsdf asdf sdf sadf</span>
													<button type="button" class="btn-circle btn-corner"><i class="fas fa-copy"></i></button>
													</div>
												</div>
												<div id="collapse-1-1" class="collapse" aria-labelledby="heading-1-1" data-parent="#accordion-1" style="">
													<p class="text-jutify mx-1">
													ollaborative Scheduling Is Easy
													Best Employee Scheduling Software 2020 | Reviews of the Most Popular Tools & Systems (capterra.com)
														Key Topics: hourly employees, labor targets, mobile app, Buddy Punch, unlimited employees, schedules in minutes, labor costs, entire workforce, field service, drop scheduling

													</p>

												</div>
												
												<div class="alert alert-secondary d-flex mb-1 m-0 collapsed" id="heading-1-1" data-toggle="collapse" role="button" data-target="#collapse-1-2" aria-expanded="false" aria-controls="collapse-1-2" style="">
													<div>
													<h6 class="text-default mb-0"><i class="icon-action fa fa-chevron-down" style="font-size: 12px"></i> Outline 2</h6>
													<span>Content dfdsfsda fdfsafsdfsdf asdf sdf sadf</span>
													<button type="button" class="btn-circle btn-corner"><i class="fas fa-copy"></i></button>
													</div>
												</div>
												
												<div id="collapse-1-2" class="collapse" aria-labelledby="heading-1-2" data-parent="#accordion-1" style="">
													<div class="card-body pb-0 pr-0">
														<div class="kw-group-items">
														Outline Item 2
														</div>							
													</div>
												</div>
											</div>				
										</div>
									</div>
								</div>
								<!-- End of Overview Tab --> 
								<!-- Start of links Tab -->
								<div class="tab-pane fade" id="links" role="tabpanel" aria-labelledby="links-tab">
									<div class="container">
										<div class="alert alert-secondary alert-default d-flex mt-1 m-0">
											<p>dfsadf
											ds
											ffdafsd</p>
											<button type="button" class="btn-circle btn-corner"><i class="fas fa-copy"></i></button>
										</div>
										<div class="alert alert-secondary alert-default d-flex mt-1 m-0">
											<div>
											<p>Among the many roles of a manager in a business, one of the most important is scheduling the staff. After all, you can't complete work without any workers. It's vital that you put thought into the scheduling process and treat your staff professionally. – <a class="ent _Small_Business_Chron">Small Business Chron</a> This is why many managers are turning to an employee scheduling app solution. For one, it saves you, as a manager, more time and money. Not to mention, automating the scheduling process offers you consistent results, lessens mistakes, reduces costs, boosts productivity, and improves employee satisfaction What Is An E mployee Scheduling App Finances Online explain this in detail, “Employee scheduling software is a workforce and scheduling management platform that helps owners and managers administer their hourly workers. Automating the process of creating schedules produces consistent results, manages labor costs, increases productivity, and improves workforce satisfaction.
											</p>
											<span style="display: inherit; margin-top: 8px; opacity: 0.6;">
												<i class="fas fa-link"></i>
												<span style="vertical-align: middle;">External link to <a href="https://smallbusiness.chron.com/importance-scheduling-staff-43248.html" target="_blank"><u class="ng-binding">smallbusiness.chron.com</u></a></span>
											</span>
											</div>
											<button type="button" class="btn-circle btn-corner"><i class="fas fa-copy"></i></button>
										</div>
									</div>
								</div>
								<!-- End of Links Tab -->
								<!-- Start of Stats Tab -->
								<div class="tab-pane fade" id="stats" role="tabpanel" aria-labelledby="stats-tab">
									<div class="container">
										<div class="alert alert-secondary alert-default d-flex mt-1 m-0">
											<p>dfsadf
											ds
											ffdafsd</p>
											<button type="button" class="btn-circle btn-corner"><i class="fas fa-copy"></i></button>
										</div>
										<div class="alert alert-secondary alert-default d-flex mt-1 m-0">
											<div>
											<p>Among the many roles of a manager in a business, one of the most important is scheduling the staff. After all, you can't complete work without any workers. It's vital that you put thought into the scheduling process and treat your staff professionally. – <a class="ent _Small_Business_Chron">Small Business Chron</a> This is why many managers are turning to an employee scheduling app solution. For one, it saves you, as a manager, more time and money. Not to mention, automating the scheduling process offers you consistent results, lessens mistakes, reduces costs, boosts productivity, and improves employee satisfaction What Is An E mployee Scheduling App Finances Online explain this in detail, “Employee scheduling software is a workforce and scheduling management platform that helps owners and managers administer their hourly workers. Automating the process of creating schedules produces consistent results, manages labor costs, increases productivity, and improves workforce satisfaction.
											</p>
											<span style="display: inherit; margin-top: 8px; opacity: 0.6;">
												<i class="fas fa-link"></i>
												<span style="vertical-align: middle;">External link to <a href="https://smallbusiness.chron.com/importance-scheduling-staff-43248.html" target="_blank"><u class="ng-binding">smallbusiness.chron.com</u></a></span>
											</span>
											</div>
											<button type="button" class="btn-circle btn-corner"><i class="fas fa-copy"></i></button>
										</div>
									</div>
								</div>
								<!-- End of Stats Tab -->
							</div>
						</div>
						<!-- End of Top Results -->
						<!-- Topic Tab -->
						<div class="tab-pane fade" id="topics" role="tabpanel" aria-labelledby="topics-tab">
							<div class="container">
								<?php $this->load->view('secure/contentarticlebrief/topic-score-section')?>
							</div>
						</div>
						<!-- End of Topic-->
						<!-- Questions Tab -->
						<div class="tab-pane fade" id="questions" role="tabpanel" aria-labelledby="questions-tab">
							<div class="container">
								<ul class="nav nav-tabs question-option-tab" id="questionsideTab" role="tablist">
									<li class="nav-item">
										<a class="nav-link active" id="serp-tab" data-toggle="tab" href="#serp" role="tab" aria-controls="serp" aria-selected="true">SERP</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" id="people-also-ask-tab" data-toggle="tab" href="#peoplealsoask" role="tab" aria-controls="peoplealsoask" aria-selected="false">People Also Ask</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" id="quora-tab" data-toggle="tab" href="#quora" role="tab" aria-controls="quora" aria-selected="false">Quora</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" id="reddit-tab" data-toggle="tab" href="#reddit" role="tab" aria-controls="reddit" aria-selected="false">Reddit</a>
									</li>
								</ul>
							</div>
							<div class="tab-content" id="questionsideTabContent">
								<!-- SERP Tab -->
								<div class="tab-pane fade show active" id="serp" role="tabpanel" aria-labelledby="serp-tab">
									<div class="container">
										<div class="alert alert-secondary alert-default d-flex mt-1 m-0">
											<p>dfsadf
											ds
											ffdafsd</p>
											<button type="button" class="btn-circle btn-corner"><i class="fas fa-copy"></i></button>
										</div>
										<div class="alert alert-secondary alert-default d-flex mt-1 m-0">
											<div>
											<p>Among the many roles of a manager in a business, one of the most important is scheduling the staff. After all, you can't complete work without any workers. It's vital that you put thought into the scheduling process and treat your staff professionally. – <a class="ent _Small_Business_Chron">Small Business Chron</a> This is why many managers are turning to an employee scheduling app solution. For one, it saves you, as a manager, more time and money. Not to mention, automating the scheduling process offers you consistent results, lessens mistakes, reduces costs, boosts productivity, and improves employee satisfaction What Is An E mployee Scheduling App Finances Online explain this in detail, “Employee scheduling software is a workforce and scheduling management platform that helps owners and managers administer their hourly workers. Automating the process of creating schedules produces consistent results, manages labor costs, increases productivity, and improves workforce satisfaction.
											</p>
											<span style="display: inherit; margin-top: 8px; opacity: 0.6;">
												<i class="fas fa-link"></i>
												<span style="vertical-align: middle;">External link to <a href="https://smallbusiness.chron.com/importance-scheduling-staff-43248.html" target="_blank"><u class="ng-binding">smallbusiness.chron.com</u></a></span>
											</span>
											</div>
											<button type="button" class="btn-circle btn-corner"><i class="fas fa-copy"></i></button>
										</div>
									</div>
								</div>
								<!-- End of SERP Tab --> 
								<!-- People Also Ask Tab -->
								<div class="tab-pane fade" id="peoplealsoask" role="tabpanel" aria-labelledby="people-also-ask-tab">
									<div class="container">
										<div class="alert alert-secondary alert-default d-flex mt-1 m-0">
											<p>dfsadf
											ds
											ffdafsd</p>
											<button type="button" class="btn-circle btn-corner"><i class="fas fa-copy"></i></button>
										</div>
										<div class="alert alert-secondary alert-default d-flex mt-1 m-0">
											<div>
											<p>Among the many roles of a manager in a business, one of the most important is scheduling the staff. After all, you can't complete work without any workers. It's vital that you put thought into the scheduling process and treat your staff professionally. – <a class="ent _Small_Business_Chron">Small Business Chron</a> This is why many managers are turning to an employee scheduling app solution. For one, it saves you, as a manager, more time and money. Not to mention, automating the scheduling process offers you consistent results, lessens mistakes, reduces costs, boosts productivity, and improves employee satisfaction What Is An E mployee Scheduling App Finances Online explain this in detail, “Employee scheduling software is a workforce and scheduling management platform that helps owners and managers administer their hourly workers. Automating the process of creating schedules produces consistent results, manages labor costs, increases productivity, and improves workforce satisfaction.
											</p>
											<span style="display: inherit; margin-top: 8px; opacity: 0.6;">
												<i class="fas fa-link"></i>
												<span style="vertical-align: middle;">External link to <a href="https://smallbusiness.chron.com/importance-scheduling-staff-43248.html" target="_blank"><u class="ng-binding">smallbusiness.chron.com</u></a></span>
											</span>
											</div>
											<button type="button" class="btn-circle btn-corner"><i class="fas fa-copy"></i></button>
										</div>
									</div>
								</div>
								<!-- End of People Also Ask Tab --> 
								<!-- Quora Tab -->
								<div class="tab-pane fade" id="quora" role="tabpanel" aria-labelledby="quora-tab">
									<div class="container">
										<div class="alert alert-secondary alert-default d-flex mt-1 m-0">
											<p>dfsadf
											ds
											ffdafsd</p>
											<button type="button" class="btn-circle btn-corner"><i class="fas fa-copy"></i></button>
										</div>
										<div class="alert alert-secondary alert-default d-flex mt-1 m-0">
											<div>
											<p>Among the many roles of a manager in a business, one of the most important is scheduling the staff. After all, you can't complete work without any workers. It's vital that you put thought into the scheduling process and treat your staff professionally. – <a class="ent _Small_Business_Chron">Small Business Chron</a> This is why many managers are turning to an employee scheduling app solution. For one, it saves you, as a manager, more time and money. Not to mention, automating the scheduling process offers you consistent results, lessens mistakes, reduces costs, boosts productivity, and improves employee satisfaction What Is An E mployee Scheduling App Finances Online explain this in detail, “Employee scheduling software is a workforce and scheduling management platform that helps owners and managers administer their hourly workers. Automating the process of creating schedules produces consistent results, manages labor costs, increases productivity, and improves workforce satisfaction.
											</p>
											<span style="display: inherit; margin-top: 8px; opacity: 0.6;">
												<i class="fas fa-link"></i>
												<span style="vertical-align: middle;">External link to <a href="https://smallbusiness.chron.com/importance-scheduling-staff-43248.html" target="_blank"><u class="ng-binding">smallbusiness.chron.com</u></a></span>
											</span>
											</div>
											<button type="button" class="btn-circle btn-corner"><i class="fas fa-copy"></i></button>
										</div>
									</div>
								</div>
								<!-- End of Quora Tab --> 
								<!-- Reddit Tab -->
								<div class="tab-pane fade" id="reddit" role="tabpanel" aria-labelledby="reddit-tab">
									<div class="container">
										<div class="alert alert-secondary alert-default d-flex mt-1 m-0">
											<p>dfsadf
											ds
											ffdafsd</p>
											<button type="button" class="btn-circle btn-corner"><i class="fas fa-copy"></i></button>
										</div>
										<div class="alert alert-secondary alert-default d-flex mt-1 m-0">
											<div>
											<p>Among the many roles of a manager in a business, one of the most important is scheduling the staff. After all, you can't complete work without any workers. It's vital that you put thought into the scheduling process and treat your staff professionally. – <a class="ent _Small_Business_Chron">Small Business Chron</a> This is why many managers are turning to an employee scheduling app solution. For one, it saves you, as a manager, more time and money. Not to mention, automating the scheduling process offers you consistent results, lessens mistakes, reduces costs, boosts productivity, and improves employee satisfaction What Is An E mployee Scheduling App Finances Online explain this in detail, “Employee scheduling software is a workforce and scheduling management platform that helps owners and managers administer their hourly workers. Automating the process of creating schedules produces consistent results, manages labor costs, increases productivity, and improves workforce satisfaction.
											</p>
											<span style="display: inherit; margin-top: 8px; opacity: 0.6;">
												<i class="fas fa-link"></i>
												<span style="vertical-align: middle;">External link to <a href="https://smallbusiness.chron.com/importance-scheduling-staff-43248.html" target="_blank"><u class="ng-binding">smallbusiness.chron.com</u></a></span>
											</span>
											</div>
											<button type="button" class="btn-circle btn-corner"><i class="fas fa-copy"></i></button>
										</div>
									</div>
								</div>
								<!-- End of Reddit Tab --> 
							</div>
						</div>
						<!-- End of Questions-->
					</div>